// ===================== КАТЕГОРИИ ПК =====================
function renderCategories() {
  const grid = document.getElementById('catGrid');
  if (!grid) return;
  grid.innerHTML = Object.entries(CATEGORIES).map(([key, cat]) => {
    const minPrice = PRICING.weekday[key].hour.windows[0].price;
    return `
      <div class="cat-card" data-hz="${cat.subtitle}">
        <div class="cat-card-title">${cat.title}</div>
        <div class="cat-card-zone">${cat.zone} · ${cat.seats} мест</div>
        <ul class="cat-specs">${cat.specs.map(s => `<li>${s}</li>`).join('')}</ul>
        <div class="cat-price">от <b>${minPrice} ₽</b>/час<div class="cat-seats">будни, утро</div></div>
      </div>`;
  }).join('');
}

// ===================== ТАБЛИЦА ЦЕН =====================
function renderPriceTable(dayType) {
  const table = document.getElementById('priceTable');
  if (!table) return;
  const cats = Object.keys(CATEGORIES);
  const rows = [];
  rows.push(`<thead><tr>
    <th>Категория</th><th>Длительность</th><th>Утро</th><th>День</th><th>Вечер</th><th>Ночь</th>
  </tr></thead>`);
  const body = cats.map(cat => {
    const data = PRICING[dayType][cat];
    const durRows = [
      { label: '1 час', key: 'hour' },
      { label: '3 часа', key: 'hours3' },
      { label: '5 часов', key: 'hours5' }
    ];
    return durRows.map((d, i) => {
      const w = data[d.key].windows;
      return `<tr>
        ${i === 0 ? `<td class="cat-name" rowspan="3">${cat}</td>` : ''}
        <td>${d.label}</td>
        <td class="num">${w[0].price} ₽</td>
        <td class="num">${w[1].price} ₽</td>
        <td class="num">${w[2].price} ₽</td>
        ${i === 0 ? `<td class="num" rowspan="3">${data.night} ₽</td>` : ''}
      </tr>`;
    }).join('');
  }).join('');
  table.innerHTML = rows.join('') + `<tbody>${body}</tbody>`;
}

function initPriceTabs() {
  const tabs = document.querySelectorAll('#priceTabs .tab');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      renderPriceTable(tab.dataset.day);
    });
  });
  renderPriceTable('weekday');
}

// ===================== ИГРЫ =====================
const GAMES = [
  "CS 2 + FaceIt","Standoff 2","Dota 2","PUBG","RUST","GTA V","Fortnite","Valorant","World of Tanks",
  "Among Us","APEX Legends","Arena Breakout: Infinite","Arma 3","Atomic Heart","Battlefield I","Battlefield V",
  "Battlefield 6","Battlefield 2042","BeamNG.drive","Bodycam","Call of Duty: Warzone","Cyberpunk 2077","Days Gone",
  "DayZ","Dead by Daylight","Deadlock","Detroit: Become Human","Doom Eternal","Don't Starve Together","Dota 1",
  "Escape from Tarkov","Euro Truck Simulator 2","Fallout 4","Fall Guys","FarCry 5","FarCry 6",
  "Five Nights at Freddy's: Security Breach","Forest","Forza Horizon 5","Garry's Mod","Genshin Impact",
  "Helldivers 2","Hogwarts Legacy","Horizon Forbidden West","Hunt: Showdown 1896","League of Legends",
  "Left 4 Dead 2","Lethal Company","Marvel Rivals","Minecraft","MudRunner","Overwatch 2","Palworld",
  "Path of Exile","Payday 2","PEAK","Phasmophobia","Portal 2","Red Dead Redemption 2","R.E.P.O.","Roblox","Raft",
  "Are We There Yet?","Satisfactory","SCP Secret Laboratory","Sims 4","Sons Of The Forest","Squad","Starcraft 2",
  "The Ascent","The Outlast Trials","Rainbow Six Siege","War Thunder","Warface","Ведьмак 3: Дикая Охота"
];

function renderGames() {
  const cloud = document.getElementById('gamesCloud');
  const count = document.getElementById('gamesCount');
  const search = document.getElementById('gamesSearch');
  if (!cloud) return;
  cloud.innerHTML = GAMES.map(g => `<span class="game-tag">${g}</span>`).join('');
  const update = () => {
    const q = search.value.trim().toLowerCase();
    const tags = cloud.querySelectorAll('.game-tag');
    let visible = 0;
    tags.forEach(tag => {
      const match = tag.textContent.toLowerCase().includes(q);
      tag.classList.toggle('hidden', q.length > 0 && !match);
      tag.classList.toggle('match', q.length > 0 && match);
      if (!q || match) visible++;
    });
    count.textContent = q ? `Найдено: ${visible} из ${GAMES.length}` : `Всего игр: ${GAMES.length}. Своей игры нет? Администратор установит по запросу.`;
  };
  search.addEventListener('input', update);
  update();
}

// ===================== ПРАВИЛА (аккордеон) =====================
const RULES_SECTIONS = [
  {
    title: "Общие положения",
    items: [
      "При оплате услуг вы соглашаетесь с правилами клуба",
      "Администратор вправе отказать в обслуживании при нарушении правил, без возврата средств",
      "Возврат за игровое время не производится; при форс-мажоре (свет, интернет) — компенсация в эквивалентном размере",
      "Клуб не отвечает за работу интернет-сервисов",
      "Ущерб, причинённый клиентом, компенсируется клиентом в полном размере"
    ]
  },
  {
    title: "Что запрещено в зале",
    items: [
      "Есть за игровым местом, курить (в т.ч. вейпы), употреблять алкоголь и наркотические вещества",
      "Ненормативная лексика, крики, агрессия к персоналу и посетителям",
      "Наносить ущерб оборудованию: удары по клавиатуре/мышке, столу, наушникам",
      "Находиться в зале без оплаченного времени, спать за местом",
      "Скрывать лицо, приходить в грязной одежде",
      "Приносить оружие и колюще-режущие предметы",
      "Самостоятельно передвигать/разбирать технику, лезть в электросеть, менять периферию",
      "Скачивать файлы без согласования с администратором, ставить нелицензионный софт, читы и шпионское ПО",
      "Заниматься торговлей, рекламой, азартными играми и ставками в зале"
    ]
  },
  {
    title: "Возрастные ограничения",
    items: [
      "Дети младше 9 лет — только в сопровождении взрослых",
      "Лица младше 18 лет не допускаются в ночное время (22:00–6:00)"
    ]
  }
];

function renderRules() {
  const wrap = document.getElementById('rulesAccordion');
  if (!wrap) return;
  wrap.innerHTML = RULES_SECTIONS.map((sec, i) => `
    <div class="accordion-item${i === 0 ? ' open' : ''}">
      <button type="button" class="accordion-head" data-idx="${i}">
        ${sec.title}<span class="plus">+</span>
      </button>
      <div class="accordion-body">
        <div class="accordion-body-inner"><ul>${sec.items.map(it => `<li>${it}</li>`).join('')}</ul></div>
      </div>
    </div>
  `).join('');
  wrap.querySelectorAll('.accordion-head').forEach(btn => {
    btn.addEventListener('click', () => {
      btn.closest('.accordion-item').classList.toggle('open');
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {
  renderCategories();
  initPriceTabs();
  renderGames();
  renderRules();
});
