/**
 * Тарифная сетка GAMERS.
 * Источник: актуальный прайс клуба (будни / выходной).
 * Все временные окна заданы в часах (0-23). Окна, пересекающие полночь,
 * закодированы как to > 24 (например вечер 17:00–6:00 => from:17, to:30).
 *
 * ВАЖНО ДЛЯ ВЛАДЕЛЬЦА КЛУБА:
 * — Праздничные дни приравниваются к тарифу выходного дня — это нужно
 *   либо считать вручную при подтверждении брони, либо завести календарь
 *   праздников (см. HOLIDAYS ниже, можно дополнять датами на год вперёд).
 * — Тариф выходного дня формально действует с 18:00 пятницы до 20:00
 *   воскресенья — этот сдвиг учтён в getDayType().
 */

const PRICING = {
  weekday: {
    STANDARD: {
      hour:   { windows: [ {from:6,to:11,price:80},  {from:11,to:17,price:100}, {from:17,to:30,price:110} ] },
      hours3: { windows: [ {from:6,to:11,price:190}, {from:11,to:16,price:240}, {from:16,to:30,price:270} ] },
      hours5: { windows: [ {from:6,to:10,price:250}, {from:10,to:14,price:310}, {from:14,to:30,price:360} ] },
      night:  450
    },
    POWER: {
      hour:   { windows: [ {from:6,to:11,price:90},  {from:11,to:17,price:120}, {from:17,to:30,price:130} ] },
      hours3: { windows: [ {from:6,to:11,price:220}, {from:11,to:16,price:290}, {from:16,to:30,price:330} ] },
      hours5: { windows: [ {from:6,to:10,price:290}, {from:10,to:14,price:380}, {from:14,to:30,price:440} ] },
      night:  550
    },
    ULTRA: {
      hour:   { windows: [ {from:6,to:11,price:120}, {from:11,to:17,price:150}, {from:17,to:30,price:170} ] },
      hours3: { windows: [ {from:6,to:11,price:280}, {from:11,to:16,price:360}, {from:16,to:30,price:420} ] },
      hours5: { windows: [ {from:6,to:10,price:400}, {from:10,to:14,price:500}, {from:14,to:30,price:600} ] },
      night:  750
    },
    "EPIC-2K": {
      hour:   { windows: [ {from:6,to:11,price:150}, {from:11,to:17,price:200}, {from:17,to:30,price:240} ] },
      hours3: { windows: [ {from:6,to:11,price:380}, {from:11,to:16,price:500}, {from:16,to:30,price:600} ] },
      hours5: { windows: [ {from:6,to:10,price:500}, {from:10,to:14,price:650}, {from:14,to:30,price:800} ] },
      night:  1050
    }
  },
  weekend: {
    STANDARD: {
      hour:   { windows: [ {from:6,to:11,price:90},  {from:11,to:17,price:110}, {from:17,to:30,price:130} ] },
      hours3: { windows: [ {from:6,to:11,price:220}, {from:11,to:16,price:270}, {from:16,to:20,price:330} ] },
      hours5: { windows: [ {from:6,to:10,price:300}, {from:10,to:14,price:370}, {from:14,to:18,price:450} ] },
      night:  560
    },
    POWER: {
      hour:   { windows: [ {from:6,to:11,price:100}, {from:11,to:17,price:130}, {from:17,to:30,price:150} ] },
      hours3: { windows: [ {from:6,to:11,price:240}, {from:11,to:16,price:320}, {from:16,to:20,price:380} ] },
      hours5: { windows: [ {from:6,to:10,price:340}, {from:10,to:14,price:440}, {from:14,to:18,price:530} ] },
      night:  660
    },
    ULTRA: {
      hour:   { windows: [ {from:6,to:11,price:130}, {from:11,to:17,price:180}, {from:17,to:30,price:220} ] },
      hours3: { windows: [ {from:6,to:11,price:320}, {from:11,to:16,price:430}, {from:16,to:20,price:520} ] },
      hours5: { windows: [ {from:6,to:10,price:450}, {from:10,to:14,price:620}, {from:14,to:18,price:750} ] },
      night:  950
    },
    "EPIC-2K": {
      hour:   { windows: [ {from:6,to:11,price:160}, {from:11,to:17,price:240}, {from:17,to:30,price:300} ] },
      hours3: { windows: [ {from:6,to:11,price:400}, {from:11,to:16,price:600}, {from:16,to:20,price:750} ] },
      hours5: { windows: [ {from:6,to:10,price:580}, {from:10,to:14,price:800}, {from:14,to:18,price:1000} ] },
      night:  1350
    }
  }
};

// Характеристики категорий мест — для карточек на странице
const CATEGORIES = {
  STANDARD: {
    title: "STANDARD",
    subtitle: "144Hz",
    seats: 10,
    zone: "Общая зона",
    specs: ["AMD Ryzen 5", "NVIDIA GTX 1660 6Gb", "AOC 24″ 144Hz", "HyperX Alloy FPS", "Logitech G102"]
  },
  POWER: {
    title: "POWER",
    subtitle: "165Hz",
    seats: 8,
    zone: "Общая зона",
    specs: ["AMD Ryzen 5", "NVIDIA RTX 2060 6Gb", "ASUS 24″ 165Hz 1ms", "Red Square Keyrox TKL", "Logitech G102"]
  },
  ULTRA: {
    title: "ULTRA",
    subtitle: "240Hz",
    seats: 10,
    zone: "2 буткемпа по 5 ПК",
    specs: ["AMD Ryzen 5", "NVIDIA RTX 4070 12Gb", "Samsung 25″ 240Hz 1ms", "Red Square Keyrox TKL", "Fantech UX3v2"]
  },
  "EPIC-2K": {
    title: "EPIC-2K",
    subtitle: "240Hz · 2K",
    seats: 2,
    zone: "Эксклюзивная комната",
    specs: ["AMD Ryzen 5", "RTX 5070 Ti 16Gb / 4070 Ti Super", "Samsung 27″ 240Hz 2K", "Red Square Keyrox TKL", "Ardor Prime PRO"]
  }
};

const DURATIONS = [
  { key: "hour",   label: "1 час" },
  { key: "hours3", label: "3 часа" },
  { key: "hours5", label: "5 часов" },
  { key: "night",  label: "Ночь (22:00–8:00)" }
];

/**
 * Определяет тип тарифа по дате: будни или выходной.
 * Тариф выходного дня — с 18:00 пятницы до 20:00 воскресенья.
 */
function getDayType(date) {
  const d = new Date(date);
  const day = d.getDay(); // 0 вс, 5 пт, 6 сб
  const hour = d.getHours();
  if (day === 5 && hour >= 18) return "weekend";
  if (day === 6) return "weekend";
  if (day === 0 && hour < 20) return "weekend";
  return "weekday";
}

function inWindow(hour, from, to) {
  if (to <= 24) return hour >= from && hour < to;
  return (hour >= from && hour < 24) || (hour < to - 24);
}

/**
 * Рассчитывает цену брони.
 * @param {string} category  STANDARD | POWER | ULTRA | EPIC-2K
 * @param {string} durationKey  hour | hours3 | hours5 | night
 * @param {Date} date  дата и время начала сеанса
 * @returns {{price:number, dayType:string, windowLabel:string}|null}
 */
function calcPrice(category, durationKey, date) {
  const dayType = getDayType(date);
  const table = PRICING[dayType][category];
  if (!table) return null;

  if (durationKey === "night") {
    return { price: table.night, dayType, windowLabel: "Ночной тариф" };
  }

  const hour = date.getHours();
  const windows = table[durationKey].windows;
  for (const w of windows) {
    if (inWindow(hour, w.from, w.to)) {
      return { price: w.price, dayType, windowLabel: `${w.from % 24}:00–${w.to % 24 === 0 ? "24" : w.to % 24}:00` };
    }
  }
  // время начала не попало ни в одно окно (например, слишком поздно для 5-часовой брони) —
  // возвращаем ближайшее вечернее/ночное окно как безопасный дефолт
  const fallback = windows[windows.length - 1];
  return { price: fallback.price, dayType, windowLabel: "Вечерний тариф" };
}
