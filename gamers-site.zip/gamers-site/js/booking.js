// ===================== СОСТОЯНИЕ БРОНИ =====================
const bookingState = {
  category: "STANDARD",
  seat: null,
  duration: "hour"
};

function renderCategoryPills() {
  const wrap = document.getElementById('catPills');
  wrap.innerHTML = Object.keys(CATEGORIES).map(key => `
    <button type="button" class="pill-btn${key === bookingState.category ? ' active' : ''}" data-cat="${key}">${key}</button>
  `).join('');
  wrap.querySelectorAll('.pill-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      bookingState.category = btn.dataset.cat;
      bookingState.seat = null;
      wrap.querySelectorAll('.pill-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderSeatMap();
      updateSummary();
    });
  });
}

function renderSeatMap() {
  const wrap = document.getElementById('seatMap');
  const seats = CATEGORIES[bookingState.category].seats;
  wrap.innerHTML = Array.from({ length: seats }, (_, i) => {
    const n = i + 1;
    return `<div class="seat free" data-seat="${n}">${n}</div>`;
  }).join('');
  wrap.querySelectorAll('.seat').forEach(el => {
    el.addEventListener('click', () => {
      wrap.querySelectorAll('.seat').forEach(s => s.classList.remove('selected'));
      el.classList.add('selected');
      bookingState.seat = el.dataset.seat;
      updateSummary();
    });
  });
}

function renderDurationPills() {
  const wrap = document.getElementById('durationPills');
  wrap.innerHTML = DURATIONS.map(d => `
    <button type="button" class="pill-btn${d.key === bookingState.duration ? ' active' : ''}" data-dur="${d.key}">${d.label}</button>
  `).join('');
  wrap.querySelectorAll('.pill-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      bookingState.duration = btn.dataset.dur;
      wrap.querySelectorAll('.pill-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      updateSummary();
    });
  });
}

function getSelectedDateTime() {
  const dateVal = document.getElementById('bookingDate').value;
  const timeVal = document.getElementById('bookingTime').value || "18:00";
  if (!dateVal) return null;
  return new Date(`${dateVal}T${timeVal}:00`);
}

function updateSummary() {
  const dt = getSelectedDateTime();
  const durLabel = DURATIONS.find(d => d.key === bookingState.duration)?.label || "";

  document.getElementById('sumCategory').textContent = bookingState.category;
  document.getElementById('sumSeat').textContent = bookingState.seat ? `Место №${bookingState.seat}` : "Не выбрано";
  document.getElementById('sumDuration').textContent = durLabel;

  const submitBtn = document.getElementById('submitBtn');

  if (!dt || isNaN(dt.getTime())) {
    document.getElementById('sumDateTime').textContent = "—";
    document.getElementById('sumTariff').textContent = "—";
    document.getElementById('sumTotal').textContent = "0 ₽";
    return;
  }

  const result = calcPrice(bookingState.category, bookingState.duration, dt);
  const dateStr = dt.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit', year: 'numeric' });
  const timeStr = dt.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });

  document.getElementById('sumDateTime').textContent = `${dateStr}, ${timeStr}`;
  document.getElementById('sumTariff').textContent = result ? `${result.dayType === 'weekend' ? 'Выходной' : 'Будни'} · ${result.windowLabel}` : "—";
  document.getElementById('sumTotal').textContent = result ? `${result.price} ₽` : "0 ₽";
}

function showFormMsg(text, type) {
  const msg = document.getElementById('formMsg');
  msg.textContent = text;
  msg.className = `form-msg show ${type}`;
}

function initBookingForm() {
  const form = document.getElementById('bookingForm');
  const dateInput = document.getElementById('bookingDate');
  const timeInput = document.getElementById('bookingTime');

  // минимум — сегодня
  const today = new Date();
  dateInput.min = today.toISOString().split('T')[0];
  dateInput.value = today.toISOString().split('T')[0];

  dateInput.addEventListener('change', updateSummary);
  timeInput.addEventListener('change', updateSummary);

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    if (!bookingState.seat) {
      showFormMsg("Выбери место на карте зала.", "err");
      return;
    }
    const dt = getSelectedDateTime();
    if (!dt || isNaN(dt.getTime())) {
      showFormMsg("Укажи корректные дату и время.", "err");
      return;
    }

    const name = document.getElementById('bookingName').value.trim();
    const contact = document.getElementById('bookingContact').value.trim();
    const comment = document.getElementById('bookingComment').value.trim();

    if (!name || !contact) {
      showFormMsg("Заполни имя и телефон/Telegram.", "err");
      return;
    }

    const result = calcPrice(bookingState.category, bookingState.duration, dt);
    const durLabel = DURATIONS.find(d => d.key === bookingState.duration)?.label || "";

    const payload = {
      category: bookingState.category,
      seat: bookingState.seat,
      date: dt.toISOString(),
      dateLabel: dt.toLocaleDateString('ru-RU') + " " + dt.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' }),
      duration: durLabel,
      price: result ? result.price : null,
      dayType: result ? result.dayType : null,
      name,
      contact,
      comment
    };

    const submitBtn = document.getElementById('submitBtn');
    submitBtn.disabled = true;
    submitBtn.textContent = "Отправляем...";

    try {
      const res = await fetch('/api/book', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!res.ok) throw new Error('bad status');

      showFormMsg("Заявка отправлена! Администратор подтвердит бронь в Telegram в ближайшее время.", "ok");
      form.reset();
      bookingState.seat = null;
      renderSeatMap();
      dateInput.value = today.toISOString().split('T')[0];
      updateSummary();
    } catch (err) {
      showFormMsg("Не удалось отправить заявку. Позвони +7 982 707-26-84 или напиши @dixizee в Telegram.", "err");
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = "Отправить заявку";
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  renderCategoryPills();
  renderSeatMap();
  renderDurationPills();
  initBookingForm();
  updateSummary();
});
