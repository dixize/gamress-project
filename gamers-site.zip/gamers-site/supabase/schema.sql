-- Схема для Supabase. Выполнить в SQL Editor проекта Supabase.
-- Даёт: хранение броней, защиту от двойного бронирования места на пересекающееся время,
-- базу для будущей админ-панели (подтверждение/отмена брони).

create table if not exists bookings (
  id uuid primary key default gen_random_uuid(),
  category text not null,             -- STANDARD | POWER | ULTRA | EPIC-2K
  seat text not null,                 -- номер места внутри категории
  session_date timestamptz not null,  -- дата и время начала сеанса
  duration text not null,             -- hour | hours3 | hours5 | night
  price integer,
  day_type text,                      -- weekday | weekend
  client_name text not null,
  contact text not null,
  comment text,
  status text not null default 'pending', -- pending | confirmed | cancelled
  created_at timestamptz not null default now()
);

create index if not exists idx_bookings_category_date on bookings (category, session_date);

alter table bookings enable row level security;

-- Публичная вставка разрешена (форма на сайте пишет напрямую, если решите
-- отказаться от serverless-функции и использовать Supabase JS SDK на клиенте).
-- Чтение/изменение — только через service key (сервер), не с фронта.
create policy "public can insert bookings"
  on bookings for insert
  to anon
  with check (true);
